package legalsearch.module5;
/** Brute-force SAT demo. Each literal is a signed 1-based variable; clauses are ORs of literals. */
public final class SATSolver {
    private SATSolver() {}
    public static boolean isSatisfiable(int variables,int[][] clauses){
        if(variables>25)throw new IllegalArgumentException("Demo solver supports at most 25 variables");
        for(int mask=0;mask<(1<<variables);mask++){boolean all=true;for(int[] clause:clauses){boolean sat=false;for(int lit:clause){boolean val=(mask&(1<<(Math.abs(lit)-1)))!=0;if(lit<0)val=!val;if(val){sat=true;break;}}if(!sat){all=false;break;}}if(all)return true;}return false;
    }
}
