package legalsearch.module5;
/** Validates that every clause has exactly three literals. */
public final class ThreeSAT {
    private ThreeSAT() {}
    public static boolean hasThreeLiteralsPerClause(int[][] clauses){for(int[] c:clauses)if(c.length!=3)return false;return true;}
}
