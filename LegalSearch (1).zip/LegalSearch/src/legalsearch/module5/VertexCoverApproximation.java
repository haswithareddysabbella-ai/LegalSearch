package legalsearch.module5;
import java.util.*;
public final class VertexCoverApproximation {
    private VertexCoverApproximation() {}
    /** Standard 2-approximation: repeatedly choose an uncovered edge and add both endpoints. */
    public static Set<Integer> approximate(boolean[][] graph){
        int n=graph.length;boolean[][] covered=new boolean[n][n];Set<Integer> result=new LinkedHashSet<>();
        for(int i=0;i<n;i++)for(int j=i+1;j<n;j++)if(graph[i][j]&&!covered[i][j]){
            result.add(i);result.add(j);
            for(int a=0;a<n;a++){covered[i][a]=covered[a][i]=true;covered[j][a]=covered[a][j]=true;}
        }
        return result;
    }
}
