package legalsearch.module5;
/** Tiny reduction helper: a clique in G is an independent set in the complement graph. */
public final class CliqueReduction {
    private CliqueReduction() {}
    public static boolean[][] complement(boolean[][] graph){
        int n=graph.length;boolean[][] c=new boolean[n][n];
        for(int i=0;i<n;i++)for(int j=0;j<n;j++)c[i][j]=i!=j&&!graph[i][j];
        return c;
    }
}
