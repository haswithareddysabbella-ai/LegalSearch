package legalsearch.module2;
import java.util.*;
public final class SuffixArray {
    private SuffixArray() {}
    public static int[] build(String s) {
        Integer[] idx=new Integer[s.length()]; for(int i=0;i<idx.length;i++)idx[i]=i;
        Arrays.sort(idx, (a,b)->s.substring(a).compareTo(s.substring(b)));
        return Arrays.stream(idx).mapToInt(Integer::intValue).toArray();
    }
}
