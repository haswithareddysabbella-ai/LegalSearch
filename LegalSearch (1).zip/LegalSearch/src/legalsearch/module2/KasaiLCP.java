package legalsearch.module2;
public final class KasaiLCP {
    private KasaiLCP() {}
    public static int[] build(String s, int[] sa) {
        int n=s.length(); int[] rank=new int[n], lcp=new int[Math.max(0,n-1)];
        for(int i=0;i<n;i++)rank[sa[i]]=i;
        int h=0;
        for(int i=0;i<n;i++){int r=rank[i];if(r==n-1){h=0;continue;}int j=sa[r+1];while(i+h<n&&j+h<n&&s.charAt(i+h)==s.charAt(j+h))h++;lcp[r]=h;if(h>0)h--;}
        return lcp;
    }
}
