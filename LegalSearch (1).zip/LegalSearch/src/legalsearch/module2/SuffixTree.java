package legalsearch.module2;
/** Educational suffix-tree search facade backed by substring lookup, not a full tree construction. */
public final class SuffixTree {
    private SuffixTree() {}
    public static boolean contains(String text, String pattern) { return text.contains(pattern); }
}
