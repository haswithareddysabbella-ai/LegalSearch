package legalsearch.module2;
/** Simple substring-membership demo; a production suffix automaton is more space-efficient. */
public final class SuffixAutomaton {
    private SuffixAutomaton() {}
    public static boolean contains(String text, String pattern) { return text.contains(pattern); }
}
