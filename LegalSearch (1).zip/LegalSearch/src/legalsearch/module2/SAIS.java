package legalsearch.module2;
/** Teaching placeholder: delegates to the clear suffix-sort implementation; not linear-time SA-IS. */
public final class SAIS {
    private SAIS() {}
    public static int[] build(String text) { return SuffixArray.build(text); }
}
