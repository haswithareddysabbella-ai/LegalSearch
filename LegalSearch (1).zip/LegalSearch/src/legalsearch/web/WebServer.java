package legalsearch.web;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.*;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import legalsearch.LegalDocument;
import legalsearch.module1.KMP;
import legalsearch.utils.CsvStore;

public class WebServer {
    public static void main(String[] args) throws Exception {
        CsvStore.ensureData();
        int port = 8080;
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);
        server.createContext("/api/search", WebServer::search);
        server.createContext("/api/cases", WebServer::cases);
        server.createContext("/api/add-case", WebServer::addCase);
        server.createContext("/", WebServer::staticFile);
        server.setExecutor(java.util.concurrent.Executors.newCachedThreadPool());
        server.start();
        System.out.println("LegalSearch website running at http://localhost:" + port);
        System.out.println("Press Ctrl+C to stop.");
    }
    private static void search(HttpExchange ex) throws IOException {
        Map<String,String> p=params(ex);
        String q=p.getOrDefault("q","").trim();
        List<String> results=new ArrayList<>();
        if(!q.isEmpty()) for(LegalDocument d:CsvStore.readDocuments()){
            if(KMP.indexOf(d.getText().toLowerCase(Locale.ROOT),q.toLowerCase(Locale.ROOT))>=0 ||
               KMP.indexOf(d.getTitle().toLowerCase(Locale.ROOT),q.toLowerCase(Locale.ROOT))>=0){
                results.add("{\"id\":"+json(d.getId())+",\"title\":"+json(d.getTitle())+",\"category\":"+json(d.getCategory())+",\"text\":"+json(d.getText())+"}");
            }
        }
        CsvStore.saveSearch(q,results.size());
        send(ex,200,"application/json; charset=utf-8","{\"query\":"+json(q)+",\"count\":"+results.size()+",\"results\":["+String.join(",",results)+"]}");
    }
    private static void cases(HttpExchange ex) throws IOException {
        List<String> out=new ArrayList<>();
        for(String[] c:CsvStore.readCases())out.add("{\"id\":"+json(c[0])+",\"title\":"+json(c[1])+",\"category\":"+json(c[2])+",\"status\":"+json(c[3])+"}");
        send(ex,200,"application/json; charset=utf-8","["+String.join(",",out)+"]");
    }
    private static void addCase(HttpExchange ex) throws IOException {
        if(!"POST".equalsIgnoreCase(ex.getRequestMethod())){send(ex,405,"application/json","{\"error\":\"POST required\"}");return;}
        Map<String,String> p=params(ex);
        String id=p.getOrDefault("id","").trim(), title=p.getOrDefault("title","").trim();
        String category=p.getOrDefault("category","General").trim(), status=p.getOrDefault("status","Open").trim();
        if(id.isEmpty()||title.isEmpty()){send(ex,400,"application/json","{\"error\":\"Case ID and title are required\"}");return;}
        CsvStore.addCase(id,title,category,status);send(ex,200,"application/json","{\"saved\":true}");
    }
    private static Map<String,String> params(HttpExchange ex) throws IOException {
        String raw=ex.getRequestURI().getRawQuery();
        if("POST".equalsIgnoreCase(ex.getRequestMethod()))raw=new String(ex.getRequestBody().readAllBytes(),StandardCharsets.UTF_8);
        Map<String,String> map=new HashMap<>();if(raw==null)return map;
        for(String pair:raw.split("&")){String[] kv=pair.split("=",2);map.put(URLDecoder.decode(kv[0],StandardCharsets.UTF_8),kv.length>1?URLDecoder.decode(kv[1],StandardCharsets.UTF_8):"");}
        return map;
    }
    private static void staticFile(HttpExchange ex) throws IOException {
        String path=ex.getRequestURI().getPath();if(path.equals("/"))path="/index.html";
        Path root=Paths.get("web").toAbsolutePath().normalize();
        Path file=root.resolve(path.substring(1)).normalize();
        if(!file.startsWith(root)||!Files.exists(file)||Files.isDirectory(file)){send(ex,404,"text/plain; charset=utf-8","Not found");return;}
        String name=file.getFileName().toString();String type=name.endsWith(".css")?"text/css; charset=utf-8":name.endsWith(".js")?"application/javascript; charset=utf-8":"text/html; charset=utf-8";
        byte[] bytes=Files.readAllBytes(file);ex.getResponseHeaders().set("Content-Type",type);ex.sendResponseHeaders(200,bytes.length);try(OutputStream os=ex.getResponseBody()){os.write(bytes);}
    }
    private static String json(String s) {
        StringBuilder b=new StringBuilder("\"");
        for(char c:s.toCharArray())switch(c){case '"':b.append("\\\"");break;case '\\':b.append("\\\\");break;case '\n':b.append("\\n");break;case '\r':b.append("\\r");break;case '\t':b.append("\\t");break;default:if(c<32)b.append(String.format("\\u%04x",(int)c));else b.append(c);}
        return b.append('"').toString();
    }
    private static void send(HttpExchange ex,int code,String type,String body)throws IOException{
        byte[] bytes=body.getBytes(StandardCharsets.UTF_8);ex.getResponseHeaders().set("Content-Type",type);ex.getResponseHeaders().set("Access-Control-Allow-Origin","*");ex.sendResponseHeaders(code,bytes.length);try(OutputStream os=ex.getResponseBody()){os.write(bytes);}
    }
}
