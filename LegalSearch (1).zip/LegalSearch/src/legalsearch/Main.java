package legalsearch;

import java.io.IOException;
import java.util.*;
import legalsearch.module1.*;
import legalsearch.module2.*;
import legalsearch.module3.*;
import legalsearch.module4.*;
import legalsearch.module5.*;
import legalsearch.module6.*;
import legalsearch.utils.CsvStore;

public class Main {
    private static final Scanner SC = new Scanner(System.in);
    public static void main(String[] args) {
        try { CsvStore.ensureData(); } catch(IOException e){System.out.println("Could not initialize data folder: "+e.getMessage());}
        System.out.println("=== LegalSearch: Intelligent Legal Document Analytics ===");
        while(true){
            System.out.println("\n1. Search legal documents\n2. Compare text / query correction\n3. View cases\n4. Add a case\n5. Run DSA module demonstrations\n0. Exit");
            System.out.print("Choose: "); String choice=SC.nextLine().trim();
            try {
                switch(choice){
                    case "1" -> search();
                    case "2" -> compare();
                    case "3" -> viewCases();
                    case "4" -> addCase();
                    case "5" -> demos();
                    case "0" -> {System.out.println("Goodbye.");return;}
                    default -> System.out.println("Please choose a listed option.");
                }
            } catch(Exception e){System.out.println("Operation failed: "+e.getMessage());}
        }
    }
    private static void search() throws IOException {
        System.out.print("Enter a term or phrase: ");String q=SC.nextLine().trim();if(q.isEmpty()){System.out.println("Search term is empty.");return;}
        int count=0;
        for(LegalDocument d:CsvStore.readDocuments()){
            if(KMP.indexOf(d.getText().toLowerCase(Locale.ROOT),q.toLowerCase(Locale.ROOT))>=0 ||
               KMP.indexOf(d.getTitle().toLowerCase(Locale.ROOT),q.toLowerCase(Locale.ROOT))>=0){
                System.out.println(d.getId()+" | "+d.getTitle()+" | "+d.getCategory());count++;
            }
        }
        CsvStore.saveSearch(q,count);System.out.println("Results: "+count);
    }
    private static void compare(){
        System.out.print("First text: ");String a=SC.nextLine();
        System.out.print("Second text: ");String b=SC.nextLine();
        System.out.println("Levenshtein edit distance: "+EditDistance.levenshtein(a,b));
        System.out.println("Weighted edit distance (insert/delete=1, replace=2): "+WeightedEditDistance.distance(a,b,1,1,2));
    }
    private static void viewCases() throws IOException {
        for(String[] c:CsvStore.readCases())System.out.println(c[0]+" | "+c[1]+" | "+c[2]+" | "+c[3]);
    }
    private static void addCase() throws IOException {
        System.out.print("Case ID: ");String id=SC.nextLine().trim();
        System.out.print("Title: ");String title=SC.nextLine().trim();
        System.out.print("Category: ");String category=SC.nextLine().trim();
        System.out.print("Status: ");String status=SC.nextLine().trim();
        CsvStore.addCase(id,title,category,status);System.out.println("Case saved to data/cases.csv");
    }
    private static void demos() {
        System.out.println("\nModule 1 — String algorithms");
        System.out.println("KMP match index in 'contract clause': "+KMP.indexOf("contract clause","clause"));
        System.out.println("Z-array for 'ababa': "+Arrays.toString(ZFunction.compute("ababa")));
        System.out.println("Rabin-Karp match index: "+RabinKarp.indexOf("case-C001-contract","C001"));
        System.out.println("Aho-Corasick term demo: "+AhoCorasick.findTerms("contract breach and tenant rights",Arrays.asList("contract","tenant","appeal")));
        System.out.println("\nModule 2 — Suffix structures");
        int[] sa=SuffixArray.build("legal");System.out.println("Suffix array for 'legal': "+Arrays.toString(sa));
        System.out.println("LCP array: "+Arrays.toString(KasaiLCP.build("legal",sa)));
        System.out.println("Substring 'egal' found: "+SuffixAutomaton.contains("legal","egal")+" (teaching demo)");
        System.out.println("\nModule 3 — Dynamic programming");
        System.out.println("Edit distance law/laws: "+EditDistance.levenshtein("law","laws"));
        System.out.println("Matrix chain minimum multiplications: "+MatrixChainMultiplication.minimumMultiplications(new int[]{10,30,5,60}));
        System.out.println("Bitmask assignment cost: "+BitmaskDP.minimumAssignmentCost(new int[][]{{9,2,7},{6,4,3},{5,8,1}}));
        System.out.println("\nModule 4 — Network flow / matching");
        int[][] cap={{0,3,2,0},{0,0,0,2},{0,0,0,3},{0,0,0,0}};
        System.out.println("Example max flow: "+EdmondsKarp.maxFlow(cap,0,3));
        System.out.println("Lawyer-case matching size: "+BipartiteMatching.maximumMatching(new boolean[][]{{true,true},{true,false}}));
        System.out.println("\nModule 5 — NP-completeness / approximation");
        System.out.println("SAT demo satisfiable: "+SATSolver.isSatisfiable(2,new int[][]{{1,2},{-1,2}}));
        System.out.println("3-SAT clause shape valid: "+ThreeSAT.hasThreeLiteralsPerClause(new int[][]{{1,-2,3}}));
        System.out.println("Vertex-cover 2-approx example: "+VertexCoverApproximation.approximate(new boolean[][]{{false,true,false},{true,false,true},{false,true,false}}));
        System.out.println("\nModule 6 — Randomized / parallel");
        int[] nums={7,2,9,1,4};RandomizedQuickSort.sort(nums);System.out.println("Randomized quicksort: "+Arrays.toString(nums));
        System.out.println("Reservoir sample of 1..5 (k=2): "+ReservoirSampling.sample(Arrays.asList(1,2,3,4,5),2));
        System.out.println("Miller-Rabin probable prime 101: "+MillerRabin.isProbablePrime(101,5));
        System.out.println("Prefix scan: "+Arrays.toString(BlellochScan.inclusiveScan(new int[]{1,2,3,4})));
        System.out.println("Parallel sum: "+ParallelReduce.sum(new int[]{1,2,3,4,5}));
        System.out.println("Brent bound W=100,S=10,p=4: "+BrentsTheorem.timeBound(100,10,4));
    }
}
