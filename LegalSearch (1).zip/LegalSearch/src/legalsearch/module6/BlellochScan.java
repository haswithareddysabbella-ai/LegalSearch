package legalsearch.module6;
/** Inclusive prefix sums using a simple sequential demonstration. */
public final class BlellochScan {
    private BlellochScan() {}
    public static int[] inclusiveScan(int[] input){int[] out=new int[input.length];int sum=0;for(int i=0;i<input.length;i++){sum+=input[i];out[i]=sum;}return out;}
}
