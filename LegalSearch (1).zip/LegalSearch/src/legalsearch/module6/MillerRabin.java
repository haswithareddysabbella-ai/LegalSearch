package legalsearch.module6;
import java.math.BigInteger;
import java.security.SecureRandom;
public final class MillerRabin {
    private MillerRabin() {}
    public static boolean isProbablePrime(long n,int rounds){
        if(n<2)return false;if(n==2||n==3)return true;if(n%2==0)return false;
        BigInteger N=BigInteger.valueOf(n), d=BigInteger.valueOf(n-1);int s=0;while(!d.testBit(0)){d=d.shiftRight(1);s++;}
        SecureRandom random=new SecureRandom();
        for(int i=0;i<Math.max(1,rounds);i++){BigInteger a=BigInteger.valueOf(2+Math.floorMod(random.nextLong(),n-3));BigInteger x=a.modPow(d,N);if(x.equals(BigInteger.ONE)||x.equals(N.subtract(BigInteger.ONE)))continue;boolean pass=false;for(int r=1;r<s;r++){x=x.multiply(x).mod(N);if(x.equals(N.subtract(BigInteger.ONE))){pass=true;break;}}if(!pass)return false;}
        return true;
    }
}
