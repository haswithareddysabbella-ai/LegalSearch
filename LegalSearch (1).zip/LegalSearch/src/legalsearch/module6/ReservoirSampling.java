package legalsearch.module6;
import java.util.*;
public final class ReservoirSampling {
    private ReservoirSampling() {}
    public static <T> List<T> sample(Iterable<T> items,int k){
        List<T> r=new ArrayList<>();if(k<=0)return r;Random random=new Random();int i=0;
        for(T x:items){i++;if(r.size()<k)r.add(x);else{int j=random.nextInt(i);if(j<k)r.set(j,x);}}
        return r;
    }
}
