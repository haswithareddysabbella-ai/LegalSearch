package legalsearch.module6;
import java.util.concurrent.ThreadLocalRandom;
public final class RandomizedQuickSort {
    private RandomizedQuickSort() {}
    public static void sort(int[] a){if(a!=null&&a.length>1)quick(a,0,a.length-1);}
    private static void quick(int[] a,int l,int r){if(l>=r)return;int p=ThreadLocalRandom.current().nextInt(l,r+1);int t=a[p];a[p]=a[r];a[r]=t;int pivot=a[r],i=l;for(int j=l;j<r;j++)if(a[j]<=pivot){t=a[i];a[i++]=a[j];a[j]=t;}t=a[i];a[i]=a[r];a[r]=t;quick(a,l,i-1);quick(a,i+1,r);}
}
