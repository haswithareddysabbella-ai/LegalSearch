package legalsearch.module6;
import java.util.concurrent.*;
public final class ParallelReduce {
    private ParallelReduce() {}
    public static long sum(int[] values) {
        if(values.length==0)return 0;
        int chunks=Math.min(Runtime.getRuntime().availableProcessors(),values.length);
        ExecutorService pool=Executors.newFixedThreadPool(chunks);
        try { Future<Long>[] fs=new Future[chunks];for(int c=0;c<chunks;c++){final int start=c*values.length/chunks,end=(c+1)*values.length/chunks;fs[c]=pool.submit(()->{long s=0;for(int i=start;i<end;i++)s+=values[i];return s;});}
            long total=0;for(Future<Long> f:fs)total+=f.get();return total;
        } catch(Exception e){throw new RuntimeException(e);} finally {pool.shutdown();}
    }
}
