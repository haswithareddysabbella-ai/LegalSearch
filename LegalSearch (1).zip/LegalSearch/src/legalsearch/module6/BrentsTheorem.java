package legalsearch.module6;
/** Returns the work bound W/p + S for a supplied work W, span S and processors p. */
public final class BrentsTheorem {
    private BrentsTheorem() {}
    public static double timeBound(long work,long span,int processors){if(processors<=0)throw new IllegalArgumentException("processors must be positive");return (double)work/processors+span;}
}
