package legalsearch.utils;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import legalsearch.LegalDocument;

public final class CsvStore {
    private static final Path DATA = Paths.get("data");
    private CsvStore() {}

    public static synchronized List<LegalDocument> readDocuments() throws IOException {
        ensureData();
        List<String> lines = Files.readAllLines(DATA.resolve("documents.csv"), StandardCharsets.UTF_8);
        List<LegalDocument> result = new ArrayList<>();
        for (int i = 1; i < lines.size(); i++) {
            List<String> c = parseLine(lines.get(i));
            if (c.size() >= 4) result.add(new LegalDocument(c.get(0), c.get(1), c.get(2), c.get(3)));
        }
        return result;
    }

    public static synchronized List<String[]> readCases() throws IOException {
        ensureData();
        List<String> lines = Files.readAllLines(DATA.resolve("cases.csv"), StandardCharsets.UTF_8);
        List<String[]> result = new ArrayList<>();
        for (int i = 1; i < lines.size(); i++) {
            List<String> c = parseLine(lines.get(i));
            if (c.size() >= 4) result.add(new String[]{c.get(0), c.get(1), c.get(2), c.get(3)});
        }
        return result;
    }

    public static synchronized void addCase(String id, String title, String category, String status) throws IOException {
        ensureData();
        String line = csv(id) + "," + csv(title) + "," + csv(category) + "," + csv(status) + System.lineSeparator();
        Files.writeString(DATA.resolve("cases.csv"), line, StandardCharsets.UTF_8, StandardOpenOption.APPEND);
    }

    public static synchronized void saveSearch(String query, int results) throws IOException {
        ensureData();
        String line = csv(java.time.LocalDateTime.now().toString()) + "," + csv(query) + "," + results + System.lineSeparator();
        Files.writeString(DATA.resolve("search_history.csv"), line, StandardCharsets.UTF_8, StandardOpenOption.APPEND);
    }

    public static synchronized void ensureData() throws IOException {
        Files.createDirectories(DATA);
        createIfMissing("documents.csv", "document_id,title,category,text\n");
        createIfMissing("cases.csv", "case_id,title,category,status\n");
        createIfMissing("lawyers.csv", "lawyer_id,name,specialty,available\n");
        createIfMissing("assignments.csv", "case_id,lawyer_id,status\n");
        createIfMissing("search_history.csv", "timestamp,query,result_count\n");
    }

    private static void createIfMissing(String name, String header) throws IOException {
        Path p = DATA.resolve(name);
        if (!Files.exists(p)) Files.writeString(p, header, StandardCharsets.UTF_8);
    }

    public static String csv(String s) {
        if (s == null) s = "";
        return "\"" + s.replace("\"", "\"\"") + "\"";
    }

    private static List<String> parseLine(String line) {
        List<String> out = new ArrayList<>();
        StringBuilder cell = new StringBuilder();
        boolean quoted = false;
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (ch == '"') {
                if (quoted && i + 1 < line.length() && line.charAt(i + 1) == '"') { cell.append('"'); i++; }
                else quoted = !quoted;
            } else if (ch == ',' && !quoted) {
                out.add(cell.toString()); cell.setLength(0);
            } else cell.append(ch);
        }
        out.add(cell.toString());
        return out;
    }
}
