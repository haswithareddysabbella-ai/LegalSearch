package legalsearch.module4;
import java.util.*;
public final class BipartiteMatching {
    private BipartiteMatching() {}
    public static int maximumMatching(boolean[][] edges){
        int right=edges.length==0?0:edges[0].length;int[] match=new int[right];Arrays.fill(match,-1);int count=0;
        for(int u=0;u<edges.length;u++)if(dfs(u,edges,match,new boolean[right]))count++;
        return count;
    }
    private static boolean dfs(int u,boolean[][] e,int[] m,boolean[] seen){
        for(int v=0;v<m.length;v++)if(e[u][v]&&!seen[v]){seen[v]=true;if(m[v]<0||dfs(m[v],e,m,seen)){m[v]=u;return true;}}
        return false;
    }
}
