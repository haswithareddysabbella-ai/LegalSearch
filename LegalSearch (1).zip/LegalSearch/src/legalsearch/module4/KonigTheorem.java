package legalsearch.module4;
/** König's theorem: in bipartite graphs, minimum vertex-cover size equals maximum matching size. */
public final class KonigTheorem {
    private KonigTheorem() {}
    public static int minimumVertexCoverSize(boolean[][] bipartiteEdges){return BipartiteMatching.maximumMatching(bipartiteEdges);}
}
