package legalsearch.module4;
/** Uses Edmonds-Karp BFS to find augmenting paths (a Ford-Fulkerson variant). */
public final class FordFulkerson {
    private FordFulkerson() {}
    public static int maxFlow(int[][] capacity,int source,int sink){return EdmondsKarp.maxFlow(capacity,source,sink);}
}
