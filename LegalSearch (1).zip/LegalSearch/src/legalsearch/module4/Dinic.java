package legalsearch.module4;
/** Runnable max-flow teaching facade using Edmonds-Karp for a compact starter project. */
public final class Dinic {
    private Dinic() {}
    public static int maxFlow(int[][] capacity,int source,int sink){return EdmondsKarp.maxFlow(capacity,source,sink);}
}
