package legalsearch.module4;
import java.util.*;
public final class EdmondsKarp {
    private EdmondsKarp() {}
    public static int maxFlow(int[][] capacity,int source,int sink){
        int n=capacity.length, flow=0;int[][] r=new int[n][n];for(int i=0;i<n;i++)r[i]=capacity[i].clone();
        while(true){int[] p=new int[n];Arrays.fill(p,-1);p[source]=source;Queue<Integer> q=new ArrayDeque<>();q.add(source);
            while(!q.isEmpty()&&p[sink]==-1){int u=q.remove();for(int v=0;v<n;v++)if(p[v]==-1&&r[u][v]>0){p[v]=u;q.add(v);}}
            if(p[sink]==-1)return flow;int add=Integer.MAX_VALUE;for(int v=sink;v!=source;v=p[v])add=Math.min(add,r[p[v]][v]);
            for(int v=sink;v!=source;v=p[v]){r[p[v]][v]-=add;r[v][p[v]]+=add;}flow+=add;
        }
    }
}
