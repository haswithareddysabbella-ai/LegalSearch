package legalsearch;

public class LegalDocument {
    private final String id;
    private final String title;
    private final String category;
    private final String text;

    public LegalDocument(String id, String title, String category, String text) {
        this.id = id == null ? "" : id;
        this.title = title == null ? "" : title;
        this.category = category == null ? "" : category;
        this.text = text == null ? "" : text;
    }
    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getCategory() { return category; }
    public String getText() { return text; }
}
