package legalsearch.module3;
/** Small assignment-cost DP demo: minimum cost to assign one distinct slot per row. */
public final class BitmaskDP {
    private BitmaskDP() {}
    public static int minimumAssignmentCost(int[][] cost){
        int n=cost.length, size=1<<n; int[] dp=new int[size]; java.util.Arrays.fill(dp,Integer.MAX_VALUE/4);dp[0]=0;
        for(int mask=0;mask<size;mask++){int row=Integer.bitCount(mask);if(row>=n)continue;for(int j=0;j<n;j++)if((mask&(1<<j))==0){int nm=mask|(1<<j);dp[nm]=Math.min(dp[nm],dp[mask]+cost[row][j]);}}
        return dp[size-1];
    }
}
