package legalsearch.module3;
public final class WeightedEditDistance {
    private WeightedEditDistance() {}
    public static int distance(String a,String b,int insertCost,int deleteCost,int replaceCost){
        int[][] d=new int[a.length()+1][b.length()+1];
        for(int i=1;i<=a.length();i++)d[i][0]=d[i-1][0]+deleteCost;
        for(int j=1;j<=b.length();j++)d[0][j]=d[0][j-1]+insertCost;
        for(int i=1;i<=a.length();i++)for(int j=1;j<=b.length();j++)d[i][j]=Math.min(Math.min(d[i-1][j]+deleteCost,d[i][j-1]+insertCost),d[i-1][j-1]+(a.charAt(i-1)==b.charAt(j-1)?0:replaceCost));
        return d[a.length()][b.length()];
    }
}
