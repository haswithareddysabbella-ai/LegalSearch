package legalsearch.module3;
public final class MatrixChainMultiplication {
    private MatrixChainMultiplication() {}
    public static long minimumMultiplications(int[] p){
        int n=p.length-1;if(n<=1)return 0;long[][] dp=new long[n][n];
        for(int len=2;len<=n;len++)for(int i=0;i+len-1<n;i++){int j=i+len-1;dp[i][j]=Long.MAX_VALUE;for(int k=i;k<j;k++)dp[i][j]=Math.min(dp[i][j],dp[i][k]+dp[k+1][j]+(long)p[i]*p[k+1]*p[j+1]);}
        return dp[0][n-1];
    }
}
