package legalsearch.module1;
public final class RabinKarp {
    private RabinKarp() {}
    public static int indexOf(String text, String pattern) {
        if(text==null||pattern==null||pattern.length()>text.length()) return -1;
        if(pattern.isEmpty()) return 0;
        long mod=1_000_000_007L, base=257, ph=0, th=0, power=1;
        for(int i=0;i<pattern.length();i++){ ph=(ph*base+pattern.charAt(i))%mod; th=(th*base+text.charAt(i))%mod; if(i<pattern.length()-1) power=(power*base)%mod; }
        for(int i=0;i<=text.length()-pattern.length();i++){
            if(ph==th && text.regionMatches(i,pattern,0,pattern.length())) return i;
            if(i<text.length()-pattern.length()) th=((th-text.charAt(i)*power%mod+mod)*base+text.charAt(i+pattern.length()))%mod;
        }
        return -1;
    }
}
