package legalsearch.module1;
import java.util.*;
public final class AhoCorasick {
    private AhoCorasick() {}
    public static List<String> findTerms(String text, List<String> terms) {
        List<String> found=new ArrayList<>();
        String lower=text.toLowerCase(Locale.ROOT);
        for(String term:terms) if(term!=null&&!term.isEmpty()&&lower.contains(term.toLowerCase(Locale.ROOT))&&!found.contains(term)) found.add(term);
        return found;
    }
}
